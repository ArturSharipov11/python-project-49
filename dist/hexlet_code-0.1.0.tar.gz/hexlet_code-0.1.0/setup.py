# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Описание:\n«Игры разума» — набор из пяти консольных игр, построенных по принципу популярных мобильных приложений для прокачки мозга. Каждая игра задает вопросы, на которые нужно дать правильные ответы. После трех правильных ответов считается, что игра пройдена. Неправильные ответы завершают игру и предлагают пройти ее заново.\n\n### Игры:\nКалькулятор. Арифметические выражения, которые необходимо вычислить.\nПрогрессия. Поиск пропущенных чисел в последовательности чисел.\nОпределение четного числа.\nОпределение наибольшего общего делителя.\nОпределение простого числа.\n\n### Инструкция по установке:\nmake build - сборка проекта\nmake package-install - установка с помощью pip в пользовательское окружение\n\n### Доступные команды после установки:\nbrain-even - Определение четного числа\nbrain-calc - Калькулятор\nbrain-gcd - Определение наибольшего общего делителя\nbrain-progression - Поиск пропущенных чисел в последовательности\nbrain-prime - Определение простого числа\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ArturSharipov11/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ArturSharipov11/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/ArturSharipov11/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/975929a16474c6bf15fb/maintainability" /></a>\n\nАскинема игр:\n\n https://asciinema.org/a/qcy65wOXcxHDIKGU5JnWbfmyd\n\n https://asciinema.org/a/NvR4pG6mOUoGwd0Cyt9PTzVaR\n\n https://asciinema.org/a/iZqK0oWgdj0dOTFXvS1B2u9BD\n\n https://asciinema.org/a/xCoDrA8DcZnaEY4v5jOtVEpIg\n\n https://asciinema.org/a/tWpApH7F9o7P5eiFV7laMjWGL\n',
    'author': 'artur sharipov',
    'author_email': 'sharipoffartur@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
