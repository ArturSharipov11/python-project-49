# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ArturSharipov11/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ArturSharipov11/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/ArturSharipov11/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/975929a16474c6bf15fb/maintainability" /></a>\n\n\n    https://asciinema.org/a/9zEicWaA24mPMkAH16DOhpKyz\n\nThis installation of asciinema recorder hasn\'t been linked to any asciinema.org\naccount. All unclaimed recordings (from unknown installations like this one)\nare automatically archived 7 days after upload.\n\nIf you want to preserve all recordings made on this machine, connect this\ninstallation with asciinema.org account by opening the following link:\n\n    https://asciinema.org/connect/04584070-aa8b-497c-acdb-36d08cc4a542\n\n\nView the recording at:\n\n    https://asciinema.org/a/06an2umQGSd6Ox0uROFpY9BRX\n\nThis installation of asciinema recorder hasn\'t been linked to any asciinema.org\naccount. All unclaimed recordings (from unknown installations like this one)\nare automatically archived 7 days after upload.\n\nIf you want to preserve all recordings made on this machine, connect this\ninstallation with asciinema.org account by opening the following link:\n\n    https://asciinema.org/connect/04584070-aa8b-497c-acdb-36d08cc4a542\n\n\nhttps://asciinema.org/a/M3FjSplomqxgF8Lcy5qMxNeyi\n\n    https://asciinema.org/a/SWSC1y2uwZEAgNzWm4sw3cU1e\n\n\n',
    'author': 'artur sharipov',
    'author_email': 'sharipoffartur@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
