# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ArturSharipov11/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ArturSharipov11/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/ArturSharipov11/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/975929a16474c6bf15fb/maintainability" /></a>\n\n{"version": 2, "width": 124, "height": 34, "timestamp": 1674997799, "env": {"SHELL": "/bin/zsh", "TERM": "xterm-256color"}}\n[0.015481, "o", "/Users/artursharipov/.zshrc:export:5: not valid in this context: /Users/artursharipov/.local/bin:/Users/artursharipov/.local/bin:/Users/artursharipov/.local/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:Library/Python/3.10/bin:/Users/artursharipov/Library/Python/3.10/bin:Library/Python/3.10/bin:/Users/artursharipov/Library/Python/3.10/bin:Library/Python/3.10/bin:/Users/artursharipov/Library/Python/3.10/bin\\r\\n"]\n[0.016384, "o", "\\u001b[1m\\u001b[7m%\\u001b[27m\\u001b[1m\\u001b[0m                                                                                                                           \\r \\r"]\n[0.016465, "o", "\\r\\u001b[0m\\u001b[27m\\u001b[24m\\u001b[Jartursharipov@MacBook-Air-Artur python-project-49 % \\u001b[K\\u001b[?2004h"]\n[19.714263, "o", "e"]\n[20.135652, "o", "\\bex"]\n[20.406175, "o", "i"]\n[20.727808, "o", "t"]\n[21.314864, "o", "\\u001b[?2004l\\r\\r\\n"]\n',
    'author': 'artur sharipov',
    'author_email': 'sharipoffartur@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
