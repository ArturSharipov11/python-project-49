### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArturSharipov11/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ArturSharipov11/python-project-49/actions)

<a href="https://codeclimate.com/github/ArturSharipov11/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/975929a16474c6bf15fb/maintainability" /></a>


    https://asciinema.org/a/9zEicWaA24mPMkAH16DOhpKyz

This installation of asciinema recorder hasn't been linked to any asciinema.org
account. All unclaimed recordings (from unknown installations like this one)
are automatically archived 7 days after upload.

If you want to preserve all recordings made on this machine, connect this
installation with asciinema.org account by opening the following link:

    https://asciinema.org/connect/04584070-aa8b-497c-acdb-36d08cc4a542


View the recording at:

    https://asciinema.org/a/06an2umQGSd6Ox0uROFpY9BRX

This installation of asciinema recorder hasn't been linked to any asciinema.org
account. All unclaimed recordings (from unknown installations like this one)
are automatically archived 7 days after upload.

If you want to preserve all recordings made on this machine, connect this
installation with asciinema.org account by opening the following link:

    https://asciinema.org/connect/04584070-aa8b-497c-acdb-36d08cc4a542


https://asciinema.org/a/M3FjSplomqxgF8Lcy5qMxNeyi

    https://asciinema.org/a/SWSC1y2uwZEAgNzWm4sw3cU1e


