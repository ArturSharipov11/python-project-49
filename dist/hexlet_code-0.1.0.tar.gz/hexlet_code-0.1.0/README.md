### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArturSharipov11/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ArturSharipov11/python-project-49/actions)

<a href="https://codeclimate.com/github/ArturSharipov11/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/975929a16474c6bf15fb/maintainability" /></a>
