### Hexlet tests and linter status:
[![Actions Status](https://github.com/ArturSharipov11/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ArturSharipov11/python-project-49/actions)

<a href="https://codeclimate.com/github/ArturSharipov11/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/975929a16474c6bf15fb/maintainability" /></a>

{"version": 2, "width": 124, "height": 34, "timestamp": 1674997799, "env": {"SHELL": "/bin/zsh", "TERM": "xterm-256color"}}
[0.015481, "o", "/Users/artursharipov/.zshrc:export:5: not valid in this context: /Users/artursharipov/.local/bin:/Users/artursharipov/.local/bin:/Users/artursharipov/.local/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:Library/Python/3.10/bin:/Users/artursharipov/Library/Python/3.10/bin:Library/Python/3.10/bin:/Users/artursharipov/Library/Python/3.10/bin:Library/Python/3.10/bin:/Users/artursharipov/Library/Python/3.10/bin\r\n"]
[0.016384, "o", "\u001b[1m\u001b[7m%\u001b[27m\u001b[1m\u001b[0m                                                                                                                           \r \r"]
[0.016465, "o", "\r\u001b[0m\u001b[27m\u001b[24m\u001b[Jartursharipov@MacBook-Air-Artur python-project-49 % \u001b[K\u001b[?2004h"]
[19.714263, "o", "e"]
[20.135652, "o", "\bex"]
[20.406175, "o", "i"]
[20.727808, "o", "t"]
[21.314864, "o", "\u001b[?2004l\r\r\n"]

    https://asciinema.org/a/9zEicWaA24mPMkAH16DOhpKyz

This installation of asciinema recorder hasn't been linked to any asciinema.org
account. All unclaimed recordings (from unknown installations like this one)
are automatically archived 7 days after upload.

If you want to preserve all recordings made on this machine, connect this
installation with asciinema.org account by opening the following link:

    https://asciinema.org/connect/04584070-aa8b-497c-acdb-36d08cc4a542


View the recording at:

    https://asciinema.org/a/06an2umQGSd6Ox0uROFpY9BRX

This installation of asciinema recorder hasn't been linked to any asciinema.org
account. All unclaimed recordings (from unknown installations like this one)
are automatically archived 7 days after upload.

If you want to preserve all recordings made on this machine, connect this
installation with asciinema.org account by opening the following link:

    https://asciinema.org/connect/04584070-aa8b-497c-acdb-36d08cc4a542

